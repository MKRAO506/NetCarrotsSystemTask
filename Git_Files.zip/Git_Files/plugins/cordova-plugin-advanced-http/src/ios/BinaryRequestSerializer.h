#import <Foundation/Foundation.h>
#import "AFURLRequestSerialization.h"

@interface BinaryRequestSerializer : AFHTTPRequestSerializer

+ (instancetype)serializer;

@end
