import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SidemenuPage } from './sidemenu.page';

const routes: Routes = [
  {
    path: '',
    redirectTo: '/sidemenu/main',
    pathMatch: 'full'
  },
  {
    path: '',
    component: SidemenuPage,
    children: [
      {
        path: 'main',
        loadChildren: () => import('../../home/home.module').then(m => m.HomePageModule)
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SidemenuPageRoutingModule { }
