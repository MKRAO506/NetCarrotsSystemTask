import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AlertController, LoadingController } from '@ionic/angular';
import { ListOfDefine } from 'src/app/definingRequests/ListOfDefine';

@Component({
  selector: 'app-sidemenu',
  templateUrl: './sidemenu.page.html',
  styleUrls: ['./sidemenu.page.scss'],
})
export class SidemenuPage implements OnInit {
  DelarData: any = {
    "LoginMobileNo": "",
    "OTPType": "",
    "OTP": "",
    "MemberType": "",
    "MobileNo": "3333333333",
    "Name": "Sanjay",
    "TaggedDealerSAPCode": "",
    "DealerName": "",
    "DealerMobileNo": "",
    "DOB": "",
    "FathersName": "",
    "Address": "",
    "State": "1",
    "AreaOffice": "",
    "DistrictName": "11",
    "ProfileContent": "",
    "EnrolType": "S"
  };
  loginobj: FormGroup;

  constructor(
    public listOfDefine: ListOfDefine,
    public loadingController: LoadingController,
    public alertController: AlertController,
  ) {
    this.loginobj = new FormGroup(
      {
        LoginMobileNo: new FormControl('', Validators.compose([Validators.minLength(10), Validators.maxLength(10), Validators.required])),
        MobileNo: new FormControl('', Validators.compose([Validators.minLength(10), Validators.maxLength(10), Validators.required])),
        MemberType: new FormControl('',),
        Name: new FormControl('',),
        TaggedDealerSAPCode: new FormControl('',),
        DealerName: new FormControl('',),
        DealerMobileNo: new FormControl('',),
        DOB: new FormControl('',),
        FathersName: new FormControl('',),
        Address: new FormControl('',),
        State: new FormControl('',),
        AreaOffice: new FormControl('',),
        DistrictName: new FormControl('',),
        ProfileContent: new FormControl('',),
        EnrolType: new FormControl('',),
      });
  }

  ngOnInit() {
  }

  async sendRequestToAPI() {
    const loading = await this.loadingController.create({
      cssClass: 'my-custom-class',
      message: 'Please wait...',
      duration: 2000
    });
    await loading.present();
    this.listOfDefine.getOnlinedata('http://jkcementdemo.netcarrots.in/API/JKCementService.svc/LoginAPI', this.DelarData).then(async results => {
      console.log(results);
      loading.dismiss();
      const alert = await this.alertController.create({
        cssClass: 'my-custom-class',
        header: 'Verify your number',
        subHeader: '6 digit code sent to ' + this.DelarData.MobileNo,
        backdropDismiss: false,
        inputs: [
          {
            name: 'OTP',
            type: 'tel',
            value: 123456
          }
        ],
        buttons: [
          {
            text: 'VERIFY',
            handler: (Data) => {
              console.log(Data);
              this.DelarData.OTP = Data.OTP;
              this.sendPostRequest();
            }
          }
        ]
      });
      await alert.present();
    }).catch(err => {
      console.log(err);
    }).catch(err => {
      console.log(err);
    });
  }
  async sendPostRequest() {
    const loading = await this.loadingController.create({
      cssClass: 'my-custom-class',
      message: 'Please wait...',
      duration: 2000
    });
    await loading.present();
    let Data = this.DelarData;
    this.listOfDefine.getOnlinedata('http://jkcementdemo.netcarrots.in/API/JKCementService.svc/DealerRecommendedAPI', Data).then(results => {
      console.log(results);
      loading.dismiss();
    }).catch(err => {
      console.log(err);
    });
  }
}
