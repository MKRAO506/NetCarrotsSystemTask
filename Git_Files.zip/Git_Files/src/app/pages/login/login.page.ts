import { Component, OnInit } from '@angular/core';
import { AlertController, LoadingController, NavController } from '@ionic/angular';
import { HTTP } from '@ionic-native/http/ngx';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ListOfDefine } from 'src/app/definingRequests/ListOfDefine';
import { FormControl, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  UserInfo: any = {};
  loginobj: FormGroup;
  loading: any;
  constructor(
    public alertController: AlertController,
    public navCtrl: NavController,
    public loadingController: LoadingController,
    private http: HttpClient,
    public listOfDefine: ListOfDefine,
    public httpMain: HTTP
  ) {
    this.loginobj = new FormGroup(
      {
        USERNAME: new FormControl('',
          Validators.compose(
            [Validators.minLength(10),
            Validators.maxLength(10),
            Validators.required
            ]
          )),
      });
  }

  async ngOnInit() {
    this.loading = await this.loadingController.create({
      cssClass: 'my-custom-class',
      message: 'Please wait...',
      duration: 2000
    });
    this.UserInfo.USERNAME = 9999999991;
  }
  async SignIn() {
    this.loading.present();
    this.listOfDefine.getOnlinedata('http://jkcementdemo.netcarrots.in/API/JKCementService.svc/LoginAPI', {}).then(async results => {
      console.log(results);
      this.loading.dismiss();
      const alert = await this.alertController.create({
        cssClass: 'my-custom-class',
        header: 'Verify your number',
        subHeader: '6 digit code sent to ' + this.UserInfo.USERNAME,
        backdropDismiss: false,
        inputs: [
          {
            name: 'teliphone',
            type: 'tel',
            value: 123456
          }
        ],
        buttons: [
          {
            text: 'VERIFY',
            handler: () => {
              console.log('Confirm Okay');
              this.sendPostRequest();
            }
          }
        ]
      });
      await alert.present();
    }).catch(err => {
      console.log(err);
    })

  }
  async sendPostRequest() {
    this.loading = await this.loadingController.create({
      cssClass: 'my-custom-class',
      message: 'Please wait...',
      duration: 2000
    });
    await this.loading.present();
    let Data = {
      "MobileNo": this.UserInfo.USERNAME,
      "OTP": "123456",
      "OTPType": "V",
      "DeviceId": "fdsfd",
      "OSType": "IOS"
    }
    this.listOfDefine.getOnlinedata('http://jkcementdemo.netcarrots.in/API/JKCementService.svc/LoginAPI', Data).then(results => {
      this.loading.dismiss();
      console.log(results);
      this.listOfDefine.userLogin = Data;
      localStorage.setItem('USERLOGIN', JSON.stringify(Data));
      this.navCtrl.navigateRoot('/sidemenu/main');
    });
  }
}
