import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable()
export class ListOfDefine {
    SelectedItem: any;
    CartItems: any = [];
    CROSSURL: string = 'https://cors-anywhere.herokuapp.com/';
    userLogin: any;
    constructor(
        private http: HttpClient,
    ) {

    }
    public async getOnlinedata(url: string, postData: any) {
        let headers1 = new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': "basic bm92YXRpczohIU5vdmF0aXMhIQ==",
            'Access-Control-Allow-Origin': '*'
        });
        let options = {
            headers: headers1
        }
        return new Promise((resolve, reject) => {
            this.http.post(this.CROSSURL + url, postData, options)
                .subscribe(data => {
                    resolve(data)
                }, error => {
                    reject(error)
                });
        });


    }
}