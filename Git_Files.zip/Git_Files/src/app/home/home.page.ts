import { Component } from '@angular/core';
import { ListOfDefine } from '../definingRequests/ListOfDefine';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  constructor(
    public listOfDefine: ListOfDefine,
  ) { }

  ionViewDidEnter() {
    console.log(this.listOfDefine.userLogin);
  }
}
