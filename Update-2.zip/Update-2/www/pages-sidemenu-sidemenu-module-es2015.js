(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-sidemenu-sidemenu-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/sidemenu/sidemenu.page.html":
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/sidemenu/sidemenu.page.html ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-app>\n    <ion-split-pane when=\"md\" contentId=\"main\">\n        <ion-menu side=\"start\" contentId=\"main\">\n            <ion-content>\n                <form [formGroup]=\"loginobj\">\n\n                    <ion-item lines='none' style=\"border-bottom:1px solid #e8e7e7;width: 100%;\">\n                        <ion-label position=\"floating\">Login Mobile Number</ion-label>\n                        <ion-input formControlName=\"LoginMobileNo\" [(ngModel)]=\"DelarData.LoginMobileNo\" type='tel'></ion-input>\n                        <ion-icon style=\"margin-top: 30px;\" slot=\"start\" color='medium' name=\"call-outline\"></ion-icon>\n                    </ion-item>\n                    <ion-item lines='none' style=\"border-bottom:1px solid #e8e7e7;width: 100%;\">\n                        <ion-label position=\"floating\">Name</ion-label>\n                        <ion-input formControlName=\"Name\" [(ngModel)]=\"DelarData.Name\" type='text'></ion-input>\n                        <ion-icon style=\"margin-top: 30px;\" slot=\"start\" color='medium' name=\"person-outline\"></ion-icon>\n                    </ion-item>\n                    <ion-item lines='none' style=\"border-bottom:1px solid #e8e7e7;width: 100%;\">\n                        <ion-label position=\"floating\">Mobile Number</ion-label>\n                        <ion-input formControlName=\"MobileNo\" [(ngModel)]=\"this.DelarData.MobileNo\" type='text'></ion-input>\n                        <ion-icon style=\"margin-top: 30px;\" slot=\"start\" color='medium' name=\"call-outline\"></ion-icon>\n                    </ion-item>\n                    <ion-item lines='none' style=\"border-bottom:1px solid #e8e7e7;width: 100%;\">\n                        <ion-label position=\"floating\">Tagged Dealer SAP Code</ion-label>\n                        <ion-input formControlName=\"TaggedDealerSAPCode\" [(ngModel)]=\"this.DelarData.TaggedDealerSAPCode\" type='tel'></ion-input>\n                        <ion-icon style=\"margin-top: 30px;\" slot=\"start\" color='medium' name=\"code-outline\"></ion-icon>\n                    </ion-item>\n                    <ion-item lines='none' style=\"border-bottom:1px solid #e8e7e7;width: 100%;\">\n                        <ion-label position=\"floating\">Dealer Name</ion-label>\n                        <ion-input formControlName=\"DealerName\" [(ngModel)]=\"this.DelarData.DealerName\" type='text'></ion-input>\n                        <ion-icon style=\"margin-top: 30px;\" slot=\"start\" color='medium' name=\"people-outline\"></ion-icon>\n                    </ion-item>\n                    <ion-item lines='none' style=\"border-bottom:1px solid #e8e7e7;width: 100%;\">\n                        <ion-label position=\"floating\">Member Type</ion-label>\n                        <ion-input formControlName=\"MemberType\" [(ngModel)]=\"this.DelarData.MemberType\" type='text'></ion-input>\n                        <ion-icon style=\"margin-top: 30px;\" slot=\"start\" color='medium' name=\"hammer-outline\"></ion-icon>\n                    </ion-item>\n                    <ion-item lines='none' style=\"border-bottom:1px solid #e8e7e7;width: 100%;\">\n                        <ion-label position=\"floating\">Dealer Mobile Number</ion-label>\n                        <ion-input formControlName=\"DealerMobileNo\" [(ngModel)]=\"this.DelarData.DealerMobileNo\" type='text'></ion-input>\n                        <ion-icon style=\"margin-top: 30px;\" slot=\"start\" color='medium' name=\"call-outline\"></ion-icon>\n                    </ion-item>\n                    <ion-item lines='none' style=\"border-bottom:1px solid #e8e7e7;width: 100%;\">\n                        <ion-label position=\"floating\">DOB</ion-label>\n                        <ion-input formControlName=\"DOB\" [(ngModel)]=\"this.DelarData.DOB\" placeholder=\"DOB\" type='date'></ion-input>\n                        <ion-icon style=\"margin-top: 30px;\" slot=\"start\" color='medium' name=\"calendar-outline\"></ion-icon>\n                    </ion-item>\n                    <ion-item lines='none' style=\"border-bottom:1px solid #e8e7e7;width: 100%;\">\n                        <ion-label position=\"floating\">Fathers Name</ion-label>\n                        <ion-input formControlName=\"FathersName\" [(ngModel)]=\"this.DelarData.FathersName\" type='text'></ion-input>\n                        <ion-icon style=\"margin-top: 30px;\" slot=\"start\" color='medium' name=\"people-circle-outline\"></ion-icon>\n                    </ion-item>\n                    <ion-item lines='none' style=\"border-bottom:1px solid #e8e7e7;width: 100%;\">\n                        <ion-label position=\"floating\">Address</ion-label>\n                        <ion-input formControlName=\"Address\" [(ngModel)]=\"this.DelarData.Address\" type='text'></ion-input>\n                        <ion-icon style=\"margin-top: 30px;\" slot=\"start\" color='medium' name=\"walk-outline\"></ion-icon>\n                    </ion-item>\n                    <ion-item lines='none' style=\"border-bottom:1px solid #e8e7e7;width: 100%;\">\n                        <ion-label position=\"floating\">State</ion-label>\n                        <ion-input formControlName=\"State\" [(ngModel)]=\"this.DelarData.State\" type='text'></ion-input>\n                        <ion-icon style=\"margin-top: 30px;\" slot=\"start\" color='medium' name=\"man-outline\"></ion-icon>\n                    </ion-item>\n                    <ion-item lines='none' style=\"border-bottom:1px solid #e8e7e7;width: 100%;\">\n                        <ion-label position=\"floating\">Area Office</ion-label>\n                        <ion-input formControlName=\"AreaOffice\" [(ngModel)]=\"this.DelarData.AreaOffice\" type='text'></ion-input>\n                        <ion-icon style=\"margin-top: 30px;\" slot=\"start\" color='medium' name=\"watch-outline\"></ion-icon>\n                    </ion-item>\n                    <ion-item lines='none' style=\"border-bottom:1px solid #e8e7e7;width: 100%;\">\n                        <ion-label position=\"floating\">District Name</ion-label>\n                        <ion-input formControlName=\"DistrictName\" [(ngModel)]=\"this.DelarData.DistrictName\" type='text'></ion-input>\n                        <ion-icon style=\"margin-top: 30px;\" slot=\"start\" color='medium' name=\"rose-outline\"></ion-icon>\n                    </ion-item>\n                    <ion-item lines='none' style=\"border-bottom:1px solid #e8e7e7;width: 100%;\">\n                        <ion-label position=\"floating\">Profile Content</ion-label>\n                        <ion-input formControlName=\"ProfileContent\" [(ngModel)]=\"this.DelarData.ProfileContent\" type='text'></ion-input>\n                        <ion-icon style=\"margin-top: 30px;\" slot=\"start\" color='medium' name=\"wallet-outline\"></ion-icon>\n                    </ion-item>\n                    <ion-item lines='none' style=\"border-bottom:1px solid #e8e7e7;width: 100%;\">\n                        <ion-label position=\"floating\">EnrolType</ion-label>\n                        <ion-input formControlName=\"EnrolType\" [(ngModel)]=\"this.DelarData.EnrolType\" type='text'></ion-input>\n                        <ion-icon style=\"margin-top: 30px;\" slot=\"start\" color='medium' name=\"water-outline\"></ion-icon>\n                    </ion-item>\n                    <ion-item lines='none' style=\"border-bottom:1px solid #e8e7e7;width: 100%;\">\n                        <ion-button [disabled]='!loginobj.valid' (click)=\"sendRequestToAPI(DelarData)\" style=\"width: 100%;\" expand=\"block\" shape=\"round\">\n                            <ion-label style=\"color: white !important;font-size: larger !important;\">submit</ion-label>\n                            <ion-icon name=\"chevron-forward-circle-outline\" slot=\"end\"></ion-icon>\n                        </ion-button>\n                    </ion-item>\n                    </form>\n            </ion-content>\n        </ion-menu>\n        <ion-router-outlet id=\"main\"></ion-router-outlet>\n    </ion-split-pane>\n</ion-app>");

/***/ }),

/***/ "./src/app/pages/sidemenu/sidemenu-routing.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/pages/sidemenu/sidemenu-routing.module.ts ***!
  \***********************************************************/
/*! exports provided: SidemenuPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SidemenuPageRoutingModule", function() { return SidemenuPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _sidemenu_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./sidemenu.page */ "./src/app/pages/sidemenu/sidemenu.page.ts");




const routes = [
    {
        path: '',
        redirectTo: '/sidemenu/main',
        pathMatch: 'full'
    },
    {
        path: '',
        component: _sidemenu_page__WEBPACK_IMPORTED_MODULE_3__["SidemenuPage"],
        children: [
            {
                path: 'main',
                loadChildren: () => __webpack_require__.e(/*! import() | home-home-module */ "home-home-module").then(__webpack_require__.bind(null, /*! ../../home/home.module */ "./src/app/home/home.module.ts")).then(m => m.HomePageModule)
            }
        ]
    }
];
let SidemenuPageRoutingModule = class SidemenuPageRoutingModule {
};
SidemenuPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], SidemenuPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/sidemenu/sidemenu.module.ts":
/*!***************************************************!*\
  !*** ./src/app/pages/sidemenu/sidemenu.module.ts ***!
  \***************************************************/
/*! exports provided: SidemenuPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SidemenuPageModule", function() { return SidemenuPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _sidemenu_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./sidemenu-routing.module */ "./src/app/pages/sidemenu/sidemenu-routing.module.ts");
/* harmony import */ var _sidemenu_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./sidemenu.page */ "./src/app/pages/sidemenu/sidemenu.page.ts");







let SidemenuPageModule = class SidemenuPageModule {
};
SidemenuPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _sidemenu_routing_module__WEBPACK_IMPORTED_MODULE_5__["SidemenuPageRoutingModule"]
        ],
        declarations: [_sidemenu_page__WEBPACK_IMPORTED_MODULE_6__["SidemenuPage"]]
    })
], SidemenuPageModule);



/***/ }),

/***/ "./src/app/pages/sidemenu/sidemenu.page.scss":
/*!***************************************************!*\
  !*** ./src/app/pages/sidemenu/sidemenu.page.scss ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-label {\n  color: #3b7577 !important;\n  font-size: small !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvc2lkZW1lbnUvc2lkZW1lbnUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0kseUJBQUE7RUFDQSwyQkFBQTtBQUNKIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvc2lkZW1lbnUvc2lkZW1lbnUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWxhYmVsIHtcclxuICAgIGNvbG9yOiAjM2I3NTc3ICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXNpemU6IHNtYWxsICFpbXBvcnRhbnQ7XHJcbn0iXX0= */");

/***/ }),

/***/ "./src/app/pages/sidemenu/sidemenu.page.ts":
/*!*************************************************!*\
  !*** ./src/app/pages/sidemenu/sidemenu.page.ts ***!
  \*************************************************/
/*! exports provided: SidemenuPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SidemenuPage", function() { return SidemenuPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var src_app_definingRequests_ListOfDefine__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/definingRequests/ListOfDefine */ "./src/app/definingRequests/ListOfDefine.ts");





let SidemenuPage = class SidemenuPage {
    constructor(listOfDefine, loadingController, alertController) {
        this.listOfDefine = listOfDefine;
        this.loadingController = loadingController;
        this.alertController = alertController;
        this.DelarData = {
            "LoginMobileNo": "",
            "OTPType": "",
            "OTP": "",
            "MemberType": "",
            "MobileNo": "3333333333",
            "Name": "Sanjay",
            "TaggedDealerSAPCode": "",
            "DealerName": "",
            "DealerMobileNo": "",
            "DOB": "",
            "FathersName": "",
            "Address": "",
            "State": "1",
            "AreaOffice": "",
            "DistrictName": "11",
            "ProfileContent": "",
            "EnrolType": "S"
        };
        this.loginobj = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormGroup"]({
            LoginMobileNo: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(10), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].maxLength(10), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])),
            MobileNo: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(10), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].maxLength(10), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])),
            MemberType: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](''),
            Name: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](''),
            TaggedDealerSAPCode: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](''),
            DealerName: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](''),
            DealerMobileNo: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](''),
            DOB: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](''),
            FathersName: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](''),
            Address: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](''),
            State: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](''),
            AreaOffice: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](''),
            DistrictName: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](''),
            ProfileContent: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](''),
            EnrolType: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](''),
        });
    }
    ngOnInit() {
    }
    sendRequestToAPI() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                cssClass: 'my-custom-class',
                message: 'Please wait...',
                duration: 2000
            });
            yield loading.present();
            this.listOfDefine.getOnlinedata('http://jkcementdemo.netcarrots.in/API/JKCementService.svc/LoginAPI', this.DelarData).then((results) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                console.log(results);
                loading.dismiss();
                const alert = yield this.alertController.create({
                    cssClass: 'my-custom-class',
                    header: 'Verify your number',
                    subHeader: '6 digit code sent to ' + this.DelarData.MobileNo,
                    backdropDismiss: false,
                    inputs: [
                        {
                            name: 'OTP',
                            type: 'tel',
                            value: 123456
                        }
                    ],
                    buttons: [
                        {
                            text: 'VERIFY',
                            handler: (Data) => {
                                console.log(Data);
                                this.DelarData.OTP = Data.OTP;
                                this.sendPostRequest();
                            }
                        }
                    ]
                });
                yield alert.present();
            })).catch(err => {
                console.log(err);
            }).catch(err => {
                console.log(err);
            });
        });
    }
    sendPostRequest() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                cssClass: 'my-custom-class',
                message: 'Please wait...',
                duration: 2000
            });
            yield loading.present();
            let Data = this.DelarData;
            this.listOfDefine.getOnlinedata('http://jkcementdemo.netcarrots.in/API/JKCementService.svc/DealerRecommendedAPI', Data).then(results => {
                console.log(results);
                loading.dismiss();
            }).catch(err => {
                console.log(err);
            });
        });
    }
};
SidemenuPage.ctorParameters = () => [
    { type: src_app_definingRequests_ListOfDefine__WEBPACK_IMPORTED_MODULE_4__["ListOfDefine"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"] }
];
SidemenuPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-sidemenu',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./sidemenu.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/sidemenu/sidemenu.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./sidemenu.page.scss */ "./src/app/pages/sidemenu/sidemenu.page.scss")).default]
    })
], SidemenuPage);



/***/ })

}]);
//# sourceMappingURL=pages-sidemenu-sidemenu-module-es2015.js.map