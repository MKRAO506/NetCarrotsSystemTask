import { Component, OnInit } from '@angular/core';
import { AlertController, LoadingController, NavController } from '@ionic/angular';
import { HTTP } from '@ionic-native/http/ngx';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ListOfDefine } from 'src/app/definingRequests/ListOfDefine';
import { FormControl, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  UserInfo: any = {};
  loginobj: FormGroup;
  loading: any;
  constructor(
    public alertController: AlertController,
    public navCtrl: NavController,
    public loadingController: LoadingController,
    private http: HttpClient,
    public listOfDefine: ListOfDefine,
    public httpMain: HTTP
  ) {
    this.loginobj = new FormGroup(
      {
        USERNAME: new FormControl('',
          Validators.compose(
            [Validators.minLength(10),
            Validators.maxLength(10),
            Validators.required
            ]
          )),
      });
  }

  async ngOnInit() {
    this.loading = await this.loadingController.create({
      cssClass: 'my-custom-class',
      message: 'Please wait...',
      duration: 2000
    });
    this.UserInfo = { "MobileNo": 9794196982, "OTP": "", "OTPType": "", "DeviceId": "ios123", "ProgramType": "S", "OSType": "IOS" };
  }
  async SignIn() {
    this.loading.present();
    this.listOfDefine.getOnlinedata('http://jkcementdemo.netcarrots.in/API/JKCementService.svc/LoginAPI', this.UserInfo).then(async (results: any) => {
      this.loading.dismiss();
      if (results.ErrorCode == -1019) {
        console.log(results);
        const alert = await this.alertController.create({
          cssClass: 'my-custom-class',
          header: 'Verify your number',
          subHeader: '6 digit code sent to ' + this.UserInfo.MobileNo,
          backdropDismiss: false,
          inputs: [
            {
              name: 'OTP',
              type: 'tel',
              value: 123456
            }
          ],
          buttons: [
            {
              text: 'RE-SEND',
              handler: () => {
                console.log('Confirm Okay');
                this.UserInfo.OTP = ''
                this.UserInfo.OTPType = 'R'
                this.OTPRequest();
              }
            },
            {
              text: 'VERIFY',
              handler: (data) => {
                console.log('Confirm Okay');
                this.UserInfo.OTP = data.OTP
                this.UserInfo.OTPType = 'V'
                this.sendPostRequest();
              }
            }
          ]
        });
        await alert.present();
      } else {
        console.log(results);
        const alert = await this.alertController.create({
          cssClass: 'my-custom-class',
          header: results.ErrorMessage,
          backdropDismiss: false,
          buttons: [
            {
              text: 'OK',
              handler: () => {
                console.log('Confirm Okay');
              }
            }
          ]
        });
        await alert.present();
      }

    }).catch(err => {
      console.log(err);
    })

  }
  async sendPostRequest() {
    this.loading = await this.loadingController.create({
      cssClass: 'my-custom-class',
      message: 'Please wait...',
      duration: 2000
    });
    await this.loading.present();
    this.listOfDefine.getOnlinedata('http://jkcementdemo.netcarrots.in/API/JKCementService.svc/LoginAPI', this.UserInfo).then((results: any) => {
      this.loading.dismiss();
      console.log(results);
      if (results.ErrorMessage == "Success") {
        this.listOfDefine.userLogin = results;
        this.navCtrl.navigateRoot('/sidemenu/main');
      }
    });
  }
  async OTPRequest() {
    this.loading = await this.loadingController.create({
      cssClass: 'my-custom-class',
      message: 'Please wait...',
      duration: 2000
    });
    await this.loading.present();
    this.listOfDefine.getOnlinedata('http://jkcementdemo.netcarrots.in/API/JKCementService.svc/LoginAPI', this.UserInfo).then(results => {
      this.loading.dismiss();
      this.SignIn();
    });
  }
}
